1.Target 

This folder contains the A2B Linux example demo code for Thor 96 board.

2.2019-10-09-LWSC-A2B Click Thru SLA.pdf

A2B source code LICENSE Terms and Condition.

3. To Download A2B full software stack please refer the following link:

https://download.analog.com/a2b/a2bsw-00/19.3.1/ADI_A2B_Software-Rel19.3.1.exe

4. A2B_Application_code.patch

This is Thor96 custom board A2B application code modification full patch

5. Add updated new A2B network Schematic under following path(generated from Sigma Studio)

Target/examples/demo/a2b-linux/a2b-adsp-sc584-linux/a2b-app-linux_Core0/app/adi_a2b_busconfig.c

6. To compile go to following path and execute the make command

/home/root/Target/examples/demo/a2b-linux/a2b-adsp-sc584-linux/Makefiles

7. Binary path

#cd /home/root/Target/examples/demo/a2b-linux/a2b-adsp-sc584-linux/Makefilesstaging/bin/

#./a2bapp-linux -d

