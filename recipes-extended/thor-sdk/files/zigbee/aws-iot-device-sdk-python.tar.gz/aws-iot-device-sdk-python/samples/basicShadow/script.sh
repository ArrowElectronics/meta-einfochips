#!/bin/bash
echo "Running Shell script inside Python" # only for debug purpose
filename=delta.txt
var1=$(cat $filename | grep lightstatus | awk '{ printf $2 }' ) # store the string
var2=$(cat $filename | grep lightname | awk '{ printf $2 }' ) # store the string
echo "$var1" # print the status
echo "$var2" # print the lightname 
